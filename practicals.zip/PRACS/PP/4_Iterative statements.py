########################### While Loop ###########################
i = 1
n = 10

while i <= n:
    print(i)
    i = i + 1



########################### For Loop ###########################
values = range(10)

for i in values:
    print(i)
