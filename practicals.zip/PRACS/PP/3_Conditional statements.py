string ="Python"

if string == "Py":
    print ("The first condition is true")

elif string == "Pthon":
    print("The second condition is true")

elif string == "Pytho":
    print("The third condition is true")

elif string=="Python":
    print("The fourth condition is true")

else:
    print ("All the above conditions are false")