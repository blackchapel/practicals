#include <stdio.h>

int main()
{
    int p = 100, r = 2, t = 3, interest;

    __asm__ __volatile__(
        "mul %%ebx"
        : "=a"(p)
        : "a"(p), "b"(r));

    __asm__ __volatile__(
        "mul %%ebx"
        : "=a"(p)
        : "a"(p), "b"(t));

    // div function not working for some reason
    __asm__ __volatile__(
        "div %%ebx, %%eax"
        : "=a"(p)
        : "a"(p), "b"(100));

    __asm__ __volatile__(
        "mov %%eax, %%ecx"
        : "=a"(interest)
        : "a"(p));
    printf("Simple Interest = %d\n", interest);

    return 0;
}